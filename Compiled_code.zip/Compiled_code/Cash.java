package Checkout;
import java.util.*;
public class Cash {
	Cash(String s,double total)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Please insert "+total+"$ cash in the till");
		double cashpaid=sc.nextDouble();
		if(cashpaid==0.0 && s.equals("YES")) System.out.println("Alarm Activated");
		double cashbalance=cashpaid-total;
		while(cashbalance!=0.0)
		{
		  if(cashbalance>0.0)
		  {
			  System.out.println("Please collect change "+cashbalance+"$");
			  cashbalance=0.0;
		  }
		  else if (cashbalance<0.0)
		  {
			  System.out.println("Please insert "+cashbalance*(-1)+" to complete the transaction");
			  double cash=sc.nextDouble();
			  cashbalance=cashbalance+cash;
		  }
		}
		System.out.println("Thankyou");
	}
}
