package Checkout;

public class Security {
	Security()
	{
		System.out.println("Camera Activated");
	}

}
