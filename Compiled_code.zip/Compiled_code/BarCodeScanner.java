package Checkout;
import java.util.*;
public class BarCodeScanner {
	ProductInventory pi=new ProductInventory();
	Scanner sc=new Scanner(System.in);
	public double scanItem(String item,int i)
	{
		double cost=0.0;
		int id=0;
		if(item.equals("Bear"))
		{
			@SuppressWarnings("unused")
			CashierDisplay cd1=new CashierDisplay("Scan did not work..Try entering the Item ID!!!");
			id=sc.nextInt();
			@SuppressWarnings("unused")
			CashierDisplay cd2=new CashierDisplay("Getting information from ProductInventory...\n\n");
			cost=pi.getItemCost(id);
			@SuppressWarnings("unused")
			CashierDisplay cd3=new CashierDisplay(id);
			@SuppressWarnings("unused")
			CashierDisplay cd4=new CashierDisplay(cost);
		}
		else
		{
			@SuppressWarnings("unused")
			CashierDisplay cd7=new CashierDisplay("Getting information from ProductInventory...\n\n");
			id=pi.getItemId(item);
			cost=pi.getItemCost(id);
			System.out.print("Cashier Display\t");
			System.out.println("\t\t\tCustomer Display");
			@SuppressWarnings("unused")
			CashierDisplay cd6=new CashierDisplay(id);
			@SuppressWarnings("unused")
			CashierDisplay cd5=new CashierDisplay(cost);
			@SuppressWarnings("unused")
			CustomerDisplay cd8=new CustomerDisplay(id);
			@SuppressWarnings("unused")
			CustomerDisplay cd9=new CustomerDisplay(cost);
		}
		EntityData ed=new EntityData();
		ed.getItem(item, i);
		ed.getCost(cost, i);
		ed.getID(id, i);
		return cost;
	}
	public double scanItem(String item,int i,String s)
	{
		double cost=0.0;
		int id=0;
		if(item.equals("Bear"))
		{
			System.out.println("Scan did not work..Try entering the Item ID!!!");
			id=sc.nextInt();
			System.out.println("Getting information from ProductInventory...\n\n");
			cost=pi.getItemCost(id);
			System.out.print("ID="+id);
			System.out.println("Cost="+cost);
		}
		else
		{
			System.out.println("Getting information from ProductInventory...\n\n");
			id=pi.getItemId(item);
			cost=pi.getItemCost(id);
			System.out.print("ID="+id);
			System.out.println("\t\tCost="+cost);
		}
		EntityData ed=new EntityData();
		ed.getItem(item, i);
		ed.getCost(cost, i);
		ed.getID(id, i);
		return cost;
	}
}
