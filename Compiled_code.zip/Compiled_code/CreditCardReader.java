package Checkout;
import java.util.*;
public class CreditCardReader {
	
	CreditCardReader()
	{
		@SuppressWarnings("resource")
		Scanner sc=new Scanner(System.in);
		@SuppressWarnings("unused")
		CustomerDisplay c1=new CustomerDisplay("Please insert/enter credit card");
		String card=sc.next();
		@SuppressWarnings("unused")
		CustomerDisplay c2=new CustomerDisplay("Enter Expiry date");
		String expiry=sc.next();
		BankServer bs=new BankServer();
		int status=bs.Bankserver(card, expiry);
		if(status==1)
		{
			CashierDisplay cd1=new CashierDisplay("Transaction authorized !!");
			CustomerDisplay c3=new CustomerDisplay("Transaction authorized !!");
		}
		else
		{
			CashierDisplay cd2=new CashierDisplay("Transaction not approved..Order cancelled!!");
			CustomerDisplay c4=new CustomerDisplay("Transaction not approved..Order cancelled!!");
		}
	}
	CreditCardReader(String s)
	{
		@SuppressWarnings("resource")
		Scanner sc=new Scanner(System.in);
		@SuppressWarnings("unused")
		CustomerDisplay c1=new CustomerDisplay("Please insert/enter credit card");
		String card=sc.next();
		@SuppressWarnings("unused")
		CustomerDisplay c2=new CustomerDisplay("Enter Expiry date");
		String expiry=sc.next();
		BankServer bs=new BankServer();
		int status=bs.Bankserver(card, expiry);
		if(status==1)
		{
			CustomerDisplay c3=new CustomerDisplay("Transaction authorized !!");
		}
		else
		{
			CustomerDisplay c4=new CustomerDisplay("Transaction not approved..Order cancelled!!");
			System.out.println("Alarm activated");
		}
	}
}
