package Checkout;
import java.util.Scanner;
public class Payment {
	Payment()
	{
		@SuppressWarnings("resource")
		Scanner sc=new Scanner(System.in);
		@SuppressWarnings("unused")
		CustomerDisplay c1=new CustomerDisplay("Select Payment method \n\t\t\t1: Credit/Debit Card\t 2: Check");
		int option=sc.nextInt();
		if(option==1)
		{
			@SuppressWarnings("unused")
			CreditCardReader ccr=new CreditCardReader();
		}
		else if(option==2)
		{
			@SuppressWarnings("unused")
			CheckReader cr=new CheckReader();
		}
	}
	Payment(String s,double total)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Select Payment method \n1: Credit/Debit Card\t 2: Cash");
		int option=sc.nextInt();
		if(option==1)
		{
			CreditCardReader ccr=new CreditCardReader("SelfserviceCheckout");
		}
		else if(option==2)
		{
			Cash ch=new Cash(s,total);
		}
	}
}
