package Checkout;

public class DiscountCoupon {
	int coupons[]= {420,840,1260};
	public double Discountcoupon(int coupon,double total)
	{
		int i=0;
		while(i<coupons.length)
		{
			if(coupon==coupons[i]) {
				System.out.println("Discount applied");
				total=total-0.1*total;
				return total;
			}
			else
				System.out.println("Coupon not valid");
			i++;
		}
		return total;
	}
}
