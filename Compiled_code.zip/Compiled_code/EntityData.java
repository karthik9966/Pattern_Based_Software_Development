package Checkout;
public class EntityData {
	static String items[]=new String[10];
	static int ids[]=new int[10];
	static double costs[]=new double[10];
	static double total;
	static int count;
	void getCost(double cost,int i)
	{
		EntityData.costs[i]=cost;
	}
	void getID(int id, int i)
	{
		EntityData.ids[i]=id;
	}
	void getItem(String item,int i)
	{
		EntityData.items[i]=item;
	}
	void getTotal(double total,int count)
	{
		EntityData.count=count;
	}
}
