package Checkout;
import java.util.*;
public class CheckoutRegister {
	public static void main( String args[])
	{
		int option=0;
		@SuppressWarnings("resource")
		Scanner sc=new Scanner(System.in);
		System.out.println("Please enter 1 for Full service or 2 for self service checkout option");
		System.out.println("If no option selected, default checkout (Full service checkout) will be selected");
		option=sc.nextInt();
		if(option==2)
		{
		  SelfServiceCheckout ssc=new SelfServiceCheckout();
		}
		else
		{
		  FullServiceCheckout fsc=new FullServiceCheckout();
		}		
	}
}
