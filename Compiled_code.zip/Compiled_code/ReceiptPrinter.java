package Checkout;
public class ReceiptPrinter {
	ReceiptPrinter()
	{
		@SuppressWarnings("unused")
		CashierDisplay cd1=new CashierDisplay("Printing Receipt..\n\n");
		EntityData ed=new EntityData();
		int i=0;
		System.out.println("Item\tID\tCost\n");
		while(i<EntityData.count)
		{
			System.out.println(EntityData.items[i]+"\t"+EntityData.ids[i]+"\t"+EntityData.costs[i]);
			i++;
		}
		System.out.println("\nThank you!!");
	}
}