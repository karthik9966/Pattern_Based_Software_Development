package Checkout;
public class BankServer {
	String cards[]= {"123456789","987654321"};
	String expiry[]= {"1024","1025"};
	public int Bankserver(String card,String expiry)
	{
		for(int i=0;i<2;i++)
		{
			if(card.equals(this.cards[i]) && expiry.equals(this.expiry[i]))
			{
				return 1;
			}
		}
		return 0;
	}
}
