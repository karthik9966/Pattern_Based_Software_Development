package Checkout;
public class ProductInventory {
	public double getItemCost(int id)
	{
		double cost=0.0;
		if(id==1234)
		{
			 cost=3.25;
		}
		if(id==5678)
		{
			 cost=1.25;
		}
		if(id==91011)
		{
			 cost=5.75;
		}
		if(id==121314)
		{
			 cost=9;
		}
		if(id==151617)
		{
			 cost=11.75;
		}
		if(id==181920)
		{
			 cost=2.50;
		}
		if(id==9876)
		{
			 cost=8.25;
		}
		return cost;
	}
	public int getItemId(String s)
	{
		int id=0;
		if(s.equals("Apple"))
		{
			 id=1234;
		}
		if(s.equals("Banana"))
		{
			 id=5678;
		}
		if(s.equals("Orange"))
		{
			 id=91011;
		}
		if(s.equals("Bread"))
		{
			 id=121314;
			 System.out.println("This item is eligible for store coupon");
			 StoreCouponPrinter scp=new StoreCouponPrinter();
		}
		if(s.equals("Milk"))
		{
			 id=151617;
		}
		if(s.equals("Yogurt"))
		{
			 id=182920;
		}
		if(s.equals("Bear"))
		{
			id=9876;
		}	
		return id;
	}
}
