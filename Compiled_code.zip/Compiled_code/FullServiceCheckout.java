package Checkout;
import java.util.*;
public class FullServiceCheckout {
	FullServiceCheckout()
	{
		double total=0;
		int i=0;
		@SuppressWarnings("resource")
		Scanner sc=new Scanner(System.in);
		String item="0";
		BarCodeScanner bs=new BarCodeScanner();
		@SuppressWarnings("unused")
		CashierDisplay cd1=new CashierDisplay("Scan/Enter Items one by one and hit 0 when done with last item");
		System.out.println("\n");
		item=sc.nextLine();
		while(true)
		{
			double cost=bs.scanItem(item,i);
			@SuppressWarnings("unused")
			CashierDisplay cd2=new CashierDisplay("Scanned");
			@SuppressWarnings("unused")
			CustomerDisplay c1=new CustomerDisplay("\t\tScanned\n");
			total=(double)total+cost;
			i++;
			System.out.println("Scan next item or hit 0 if done");
			item=sc.nextLine();
			if(item.equals("0")) break;
		}
		@SuppressWarnings("unused")
		CashierDisplay cd3=new CashierDisplay("CashierDisplay\t\t\t\tCustomerDisplay\n\nTotal cost ="+total);
		@SuppressWarnings("unused")
		CustomerDisplay c3=new CustomerDisplay("Total cost ="+total);
		System.out.println("Does customer have any discount coupon");
		String answer=sc.nextLine();
		if(answer.equals("NO")) {
		Payment p=new Payment();
		EntityData ed=new EntityData();
		ed.getTotal(total,i);
		@SuppressWarnings("unused")
		ReceiptPrinter rp=new ReceiptPrinter();
		}
		else
		{
			System.out.println("Enter Discount coupon code");
			int coupon=sc.nextInt();
			DiscountCoupon dc=new DiscountCoupon();
			double newtotal=dc.Discountcoupon(coupon, total);
			System.out.println("Total after applying 10% discount"+newtotal);
			Payment p=new Payment();
			EntityData ed=new EntityData();
			ed.getTotal(newtotal,i);
			ReceiptPrinter rp=new ReceiptPrinter();
		}
		}
	}
