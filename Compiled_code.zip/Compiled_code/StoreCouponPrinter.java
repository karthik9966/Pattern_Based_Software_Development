package Checkout;

public class StoreCouponPrinter {
	StoreCouponPrinter()
	{
		System.out.println("Store coupon printed..Please collect");
	}
}