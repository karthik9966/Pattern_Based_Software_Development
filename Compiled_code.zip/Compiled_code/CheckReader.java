package Checkout;
import java.util.*;
public class CheckReader {
	String checks[] = {"abc","def"};
	CheckReader()
	{
		Scanner sc=new Scanner(System.in);
		CustomerDisplay cd1=new CustomerDisplay("Enter check");
		String check=sc.next();
		for(int i=0;i<2;i++)
		{
			if(check==this.checks[i])
			{
				CashierDisplay c1=new CashierDisplay("Check verified");
				CustomerDisplay cd2=new CustomerDisplay("Check verified");
			}
			
		}
		CashierDisplay c2=new CashierDisplay("Check not valid..Order cancelled!!!");
		CustomerDisplay cd3=new CustomerDisplay("Check not valid..Order cancelled!!!");
	}
}
