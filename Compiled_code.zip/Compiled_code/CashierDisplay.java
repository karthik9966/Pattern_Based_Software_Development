package Checkout;
public class CashierDisplay {
	CashierDisplay(String message)
	{
		System.out.print("\n"+message);
	}
	CashierDisplay(int message)
	{
		System.out.print("ID="+message);
	}
	CashierDisplay(double message)
	{
		System.out.print("\tCost="+message);
	}
}
