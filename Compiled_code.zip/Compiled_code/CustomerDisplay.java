package Checkout;
public class CustomerDisplay {
	CustomerDisplay(String message)
	{
		System.out.println("\t\t\t"+message);
	}
	CustomerDisplay(int message)
	{
		System.out.print("\t\t\t id="+message);
	}
	CustomerDisplay(double message)
	{
		System.out.println("\tcost="+message);
	}
}
