package Checkout;
import java.util.*;
public class SelfServiceCheckout {
	SelfServiceCheckout()
	{
		System.out.println("Do you wish to use security feature in self service checkout");
		Scanner sc= new Scanner(System.in);
		String response=sc.nextLine();
		if(response.equals("NO")) 
		{
		String item=null;
		double total=0.0;
		int i=0;
		System.out.println("Welcome!!\nPress START button to scan");
		BarCodeScanner bs=new BarCodeScanner();
		System.out.println("Scan/Enter Items one by one and hit 0 when done with last item");
		item=sc.nextLine();
		while(true)
		{
			double cost=bs.scanItem(item,i,"selfservicecheckout");
			System.out.println("Scanned\n");
			total=(double)total+cost;
			i++;
			System.out.println("Scan next item or hit 0 if done");
			item=sc.nextLine();
			if(item.equals("0")) break;
		}
		System.out.println("Total cost ="+total);
		System.out.println("Does customer have any discount coupon");
		String answer=sc.nextLine();
		if(answer.equals("NO")) {
		Payment p=new Payment("SelfServiceCheckout",total);
		EntityData ed=new EntityData();
		ed.getTotal(total,i);
		ReceiptPrinter rp=new ReceiptPrinter();
		}
		else
		{
			System.out.println("Enter Discount coupon code");
			int coupon=sc.nextInt();
			DiscountCoupon dc=new DiscountCoupon();
			double newtotal=dc.Discountcoupon(coupon, total);
			System.out.println("Total after applying 10% discount"+newtotal);
			Payment p=new Payment("SelfServiceCheckout",newtotal);
			EntityData ed=new EntityData();
			ed.getTotal(newtotal,i);
			ReceiptPrinter rp=new ReceiptPrinter();
		}
	}
	else
	{
		String item=null;
		double total=0.0;
		int i=0;
		System.out.println("Welcome!!\nPress START button to scan");
		BarCodeScanner bs=new BarCodeScanner();
		System.out.println("Scan/Enter Items one by one and hit 0 when done with last item");
		item=sc.nextLine();
		while(true)
		{
			double cost=bs.scanItem(item,i);
			Security s=new Security();
			System.out.println("Scanned\n");
			total=(double)total+cost;
			i++;
			System.out.println("Scan next item or hit 0 if done");
			item=sc.nextLine();
			if(item.equals("0")) break;
		}
		System.out.println("Total cost = "+total);
		System.out.println("Does customer have any discount coupon");
		String answer=sc.nextLine();
		if(answer.equals("NO")) {
		Payment p=new Payment(response,total);
		EntityData ed=new EntityData();
		ed.getTotal(total,i);
		ReceiptPrinter rp=new ReceiptPrinter();
		}
		else
		{
			System.out.println("Enter Discount coupon code");
			int coupon=sc.nextInt();
			DiscountCoupon dc=new DiscountCoupon();
			double newtotal=dc.Discountcoupon(coupon, total);
			System.out.println("Total after 10% discount"+newtotal);
			Payment p=new Payment(response,newtotal);
			EntityData ed=new EntityData();
			ed.getTotal(newtotal,i);
			ReceiptPrinter rp=new ReceiptPrinter();
		}
	}
	}
}
